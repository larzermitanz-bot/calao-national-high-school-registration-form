"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface FormData {
  firstName: string
  middleName: string
  lastName: string
  email: string
  lrn: string
  gradeLevel: string
  strand: string
  phone: string
  barangay: string
  municipality: string
  province: string
  parentName: string
  parentEmail: string
  parentPhone: string
  agreeToTerms: boolean
}

export function NHSRegistrationForm() {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    middleName: "",
    lastName: "",
    email: "",
    lrn: "",
    gradeLevel: "",
    strand: "",
    phone: "",
    barangay: "",
    municipality: "",
    province: "",
    parentName: "",
    parentEmail: "",
    parentPhone: "",
    agreeToTerms: false,
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (field: keyof FormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-8 pb-8 text-center">
          <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-8 h-8 text-primary"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-foreground mb-2">
            Registration Submitted
          </h2>
          <p className="text-muted-foreground mb-6">
            Thank you for your interest in the National Honor Society. Your application has been received and will be reviewed by our NHS advisors. You will receive an email confirmation shortly.
          </p>
          <Button onClick={() => setIsSubmitted(false)} variant="outline">
            Submit Another Application
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Student Information */}
      <Card>
        <CardHeader>
          <CardTitle>Student Information</CardTitle>
          <CardDescription>
            Please provide your personal and academic details
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => handleInputChange("firstName", e.target.value)}
                required
                placeholder="Juan"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="middleName">Middle Name</Label>
              <Input
                id="middleName"
                value={formData.middleName}
                onChange={(e) => handleInputChange("middleName", e.target.value)}
                placeholder="Santos"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => handleInputChange("lastName", e.target.value)}
                required
                placeholder="Dela Cruz"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lrn">Learner Reference Number (LRN) *</Label>
              <Input
                id="lrn"
                value={formData.lrn}
                onChange={(e) => handleInputChange("lrn", e.target.value)}
                required
                placeholder="12-digit LRN"
                maxLength={12}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
                placeholder="student@email.com"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="gradeLevel">Grade Level *</Label>
              <Select
                value={formData.gradeLevel}
                onValueChange={(value) => handleInputChange("gradeLevel", value)}
                required
              >
                <SelectTrigger id="gradeLevel">
                  <SelectValue placeholder="Select grade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Grade 7 (JHS)</SelectItem>
                  <SelectItem value="8">Grade 8 (JHS)</SelectItem>
                  <SelectItem value="9">Grade 9 (JHS)</SelectItem>
                  <SelectItem value="10">Grade 10 (JHS)</SelectItem>
                  <SelectItem value="11">Grade 11 (SHS)</SelectItem>
                  <SelectItem value="12">Grade 12 (SHS)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="strand">Strand/Track (SHS only)</Label>
              <Select
                value={formData.strand}
                onValueChange={(value) => handleInputChange("strand", value)}
              >
                <SelectTrigger id="strand">
                  <SelectValue placeholder="Select strand" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stem">STEM</SelectItem>
                  <SelectItem value="abm">ABM</SelectItem>
                  <SelectItem value="humss">HUMSS</SelectItem>
                  <SelectItem value="gas">GAS</SelectItem>
                  <SelectItem value="tvl-afa">TVL - Agri-Fishery Arts</SelectItem>
                  <SelectItem value="tvl-he">TVL - Home Economics</SelectItem>
                  <SelectItem value="tvl-ia">TVL - Industrial Arts</SelectItem>
                  <SelectItem value="tvl-ict">TVL - ICT</SelectItem>
                  <SelectItem value="sports">Sports Track</SelectItem>
                  <SelectItem value="arts">Arts and Design Track</SelectItem>
                  <SelectItem value="na">N/A (JHS Student)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Contact Number *</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                required
                placeholder="09XX XXX XXXX"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="barangay">Barangay *</Label>
              <Input
                id="barangay"
                value={formData.barangay}
                onChange={(e) => handleInputChange("barangay", e.target.value)}
                required
                placeholder="Barangay name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="municipality">Municipality/City *</Label>
              <Input
                id="municipality"
                value={formData.municipality}
                onChange={(e) => handleInputChange("municipality", e.target.value)}
                required
                placeholder="Municipality or City"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="province">Province *</Label>
              <Input
                id="province"
                value={formData.province}
                onChange={(e) => handleInputChange("province", e.target.value)}
                required
                placeholder="Province"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Parent/Guardian Information */}
      <Card>
        <CardHeader>
          <CardTitle>Parent/Guardian Information</CardTitle>
          <CardDescription>
            Contact information for your parent or guardian
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="parentName">Parent/Guardian Name *</Label>
            <Input
              id="parentName"
              value={formData.parentName}
              onChange={(e) => handleInputChange("parentName", e.target.value)}
              required
              placeholder="Full name of parent or guardian"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="parentEmail">Parent/Guardian Email *</Label>
              <Input
                id="parentEmail"
                type="email"
                value={formData.parentEmail}
                onChange={(e) => handleInputChange("parentEmail", e.target.value)}
                required
                placeholder="parent@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="parentPhone">Parent/Guardian Phone *</Label>
              <Input
                id="parentPhone"
                type="tel"
                value={formData.parentPhone}
                onChange={(e) => handleInputChange("parentPhone", e.target.value)}
                required
                placeholder="09XX XXX XXXX"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Agreement */}
      <Card>
        <CardHeader>
          <CardTitle>Agreement</CardTitle>
          <CardDescription>
            Please read and acknowledge the following
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-start space-x-3">
            <Checkbox
              id="agreeToTerms"
              checked={formData.agreeToTerms}
              onCheckedChange={(checked) =>
                handleInputChange("agreeToTerms", checked === true)
              }
              required
            />
            <Label htmlFor="agreeToTerms" className="text-sm leading-relaxed cursor-pointer">
              I certify that all information provided in this registration is accurate and complete. *
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-center">
        <Button
          type="submit"
          size="lg"
          className="min-w-[200px]"
          disabled={isSubmitting || !formData.agreeToTerms}
        >
          {isSubmitting ? "Submitting..." : "Submit Application"}
        </Button>
      </div>
    </form>
  )
}
