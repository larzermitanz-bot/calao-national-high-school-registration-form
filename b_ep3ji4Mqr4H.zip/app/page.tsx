import { NHSRegistrationForm } from "@/components/nhs-registration-form"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col items-center text-center">
            <div className="flex items-center gap-4 mb-4">
              <img 
                src="/images/calao-logo.png" 
                alt="Calao National High School Logo"
                className="w-20 h-20 object-contain rounded-full bg-white p-1"
              />
              <div className="text-left">
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
                  Calao National High School
                </h1>
                <p className="text-primary-foreground/80 text-lg">
                  Registration Form
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-secondary/50 border-b border-border">
        <div className="container mx-auto px-4 py-10 text-center">
          <div className="inline-block bg-accent/20 text-accent-foreground px-4 py-1.5 rounded-full text-sm font-medium mb-4">
            School Year 2026-2027
          </div>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-3 text-balance">
            Membership Registration Now Open
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Join an elite group of students committed to academic excellence. 
            Complete the application below to be considered for Calao National High School membership.
          </p>
          <a
            href="https://www.deped.gov.ph"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-4 text-sm text-primary hover:underline"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
              />
            </svg>
            Check DepEd Guidelines and Details
          </a>
        </div>
      </section>

      {/* Registration Form */}
      <section className="container mx-auto px-4 pb-16">
        <div className="max-w-3xl mx-auto">
          <NHSRegistrationForm />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-primary-foreground/80">
            Calao National High School - NHS Registration | School Year 2026-2027
          </p>
          <p className="text-xs text-primary-foreground/60 mt-2">
            Department of Education - Philippines
          </p>
          <p className="text-xs text-primary-foreground/60 mt-1">
            For questions, contact the NHS Adviser
          </p>
        </div>
      </footer>
    </div>
  )
}
