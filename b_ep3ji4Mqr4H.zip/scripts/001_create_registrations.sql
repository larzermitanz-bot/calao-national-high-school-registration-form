-- Create NHS registrations table
CREATE TABLE IF NOT EXISTS nhs_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name TEXT NOT NULL,
  middle_name TEXT,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  lrn TEXT NOT NULL,
  grade_level TEXT NOT NULL,
  strand TEXT,
  phone TEXT NOT NULL,
  barangay TEXT NOT NULL,
  municipality TEXT NOT NULL,
  province TEXT NOT NULL,
  parent_name TEXT NOT NULL,
  parent_email TEXT NOT NULL,
  parent_phone TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE nhs_registrations ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (for public registration form)
CREATE POLICY "Allow public insert" ON nhs_registrations
  FOR INSERT
  WITH CHECK (true);

-- Allow anyone to read (for admin viewing - in production, restrict this to authenticated admins)
CREATE POLICY "Allow public read" ON nhs_registrations
  FOR SELECT
  USING (true);
